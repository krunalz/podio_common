from setuptools import setup, find_packages
    
setup(
    name='podio_common',
    version='1.0.1',
    packages=find_packages(),
    install_requires=[
        # List of dependencies
    ],
    entry_points={
        'console_scripts': [
            # List of console scripts
        ]
    },
    # Other metadata
)
